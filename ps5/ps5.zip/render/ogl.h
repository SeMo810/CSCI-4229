#ifndef OGL_H_
#define OGL_H_

#define GL_GLEXT_PROTOTYPES
#ifdef __APPLE__
# include <GLUT/glut.h>
#else
# include <GL/glut.h>
#endif

#endif // OGL_H_
